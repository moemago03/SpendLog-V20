// ==========================================================================================
// IMPORTANT: ACTION REQUIRED
// ==========================================================================================
// Replace the placeholder below with the Web App URL you copied after deploying your
// Google Apps Script in Step 3 of the setup instructions.
// The app will not work until you do this.
//
// Example: export const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/ABC.../exec';
// ==========================================================================================

export const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbyP_F1h-XSphG_S0aOlo3wvuFujzsBHW4yfGL4XicgjRzbe4EjYb89qdkcHrqYG/exec';